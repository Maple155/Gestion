UPDATE bons_commande 
SET statut_finance = 'VALIDEE' 
WHERE id = 'ID_ICI';