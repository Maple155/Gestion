package com.gestion.finance.controller;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.gestion.achat.entity.*;
import com.gestion.achat.enums.StatutFinance;
import com.gestion.achat.repository.*;
import com.gestion.vente.entity.*;
import com.gestion.vente.repository.*;
import com.gestion.vente.enums.StatutPaiement;
import com.gestion.vente.enums.StatutFactureVente;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/finance")
@RequiredArgsConstructor
public class FinanceController {

    private final FactureAchatRepository factureAchatRepository;
    private final BonCommandeRepository bonCommandeRepository;
    private final PaiementClientRepository paiementClientRepository;
    private final FactureVenteRepository factureVenteRepository;

    @GetMapping("/daf")
    public String dashboardDaf(Model model, HttpSession session) {
        requireRole(session, "ADMIN", "DAF", "FINANCE");

        // Stats de base
        BigDecimal cashIn = getCashReelRecu();
        BigDecimal cashOut = getCashReelPaye();
        BigDecimal dettes = getDetteFournisseur();
        BigDecimal creances = getTotalCreancesClients();

        // Calcul du BFR (Simplifié : Créances + Stocks - Dettes)
        BigDecimal bfr = creances.subtract(dettes);

        model.addAttribute("cashIn", cashIn);
        model.addAttribute("cashOut", cashOut);
        model.addAttribute("solde", cashIn.subtract(cashOut));
        model.addAttribute("dettes", dettes);
        model.addAttribute("creances", creances);
        model.addAttribute("bfr", bfr);
        
        // Données pour le graphique (Exemple statique à dynamiser selon tes logs)
        model.addAttribute("labelsGraph", List.of("Jan", "Feb", "Mar", "Apr", "May", "Jun"));
        model.addAttribute("dataFlux", List.of(cashIn.multiply(new BigDecimal("0.8")), cashIn, cashIn.multiply(new BigDecimal("1.1"))));

        model.addAttribute("anomalies", getAnomaliesAudit());
        return "finance/daf-dashboard";
    }

    @GetMapping("/clients")
    public String financeClients(Model model, HttpSession session) {
        requireRole(session, "ADMIN", "DAF", "FINANCE");

        // Balance Âgée
        Map<String, BigDecimal> balanceAgee = factureVenteRepository.findAll().stream()
                .filter(f -> f.getStatut() != StatutFactureVente.PAYEE)
                .collect(Collectors.groupingBy(f -> f.getClient().getNom(),
                        Collectors.mapping(FactureVente::getTotalTtc, Collectors.reducing(BigDecimal.ZERO, BigDecimal::add))));

        BigDecimal totalCreances = balanceAgee.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add);

        model.addAttribute("balanceAgee", balanceAgee);
        model.addAttribute("totalCreances", totalCreances);
        return "finance/clients-dashboard";
    }

    // --- CÔTÉ FOURNISSEUR (INCHANGÉ selon tes instructions) ---
    @GetMapping("/fournisseurs")
    public String dashboardFournisseurs(@RequestParam(required = false) Boolean payee, Model model, HttpSession session) {
        requireRole(session, "ADMIN", "DAF", "FINANCE");
        List<FactureAchat> factures = factureAchatRepository.findAll().stream()
                .filter(f -> payee == null || f.isEstPayee() == payee).toList();
        
        model.addAttribute("factures", factures);
        model.addAttribute("bcListe", bonCommandeRepository.findAll());
        model.addAttribute("totalDu", getDetteFournisseur());
        model.addAttribute("engagementBc", getEngagementBcValides());
        model.addAttribute("totalPaye", getCashReelPaye());
        model.addAttribute("activePage", "finance-fournisseurs");
        return "finance/fournisseurs-dashboard";
    }

    @PostMapping("/fournisseurs/valider-bc/{id}")
    public String validerBc(@PathVariable UUID id, RedirectAttributes attrs) {
        BonCommande bc = bonCommandeRepository.findById(id).orElseThrow();
        BigDecimal dispo = getCashReelRecu().subtract(getCashReelPaye());
        if (dispo.compareTo(bc.getMontantTotalTtc()) < 0) {
            attrs.addFlashAttribute("errorMessage", "Fonds insuffisants (" + dispo + " €)");
        } else {
            bc.setStatutFinance(StatutFinance.VALIDEE);
            bonCommandeRepository.save(bc);
            attrs.addFlashAttribute("successMessage", "BC Engagé");
        }
        return "redirect:/finance/fournisseurs";
    }

    @PostMapping("/fournisseurs/payer-facture/{id}")
    public String payerFacture(@PathVariable UUID id) {
        FactureAchat f = factureAchatRepository.findById(id).orElseThrow();
        f.setEstPayee(true);
        factureAchatRepository.save(f);
        return "redirect:/finance/fournisseurs";
    }

    // HELPERS
    private BigDecimal getCashReelRecu() {
        return paiementClientRepository.findAll().stream()
            .filter(p -> p.getStatut() == StatutPaiement.ENREGISTRE)
            .map(PaiementClient::getMontant).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    private BigDecimal getCashReelPaye() {
        return factureAchatRepository.findAll().stream()
            .filter(FactureAchat::isEstPayee)
            .map(FactureAchat::getMontantTotalTtc).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    private BigDecimal getDetteFournisseur() {
        return factureAchatRepository.findAll().stream()
            .filter(f -> !f.isEstPayee())
            .map(FactureAchat::getMontantTotalTtc).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    private BigDecimal getEngagementBcValides() {
        return bonCommandeRepository.findAll().stream()
            .filter(bc -> bc.getStatutFinance() == StatutFinance.VALIDEE)
            .map(BonCommande::getMontantTotalTtc).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    private void requireRole(HttpSession session, String... roles) {
        String r = (String) session.getAttribute("userRole");
        if (r == null || Arrays.stream(roles).noneMatch(role -> role.equals(r))) throw new RuntimeException("Accès refusé");
    }
    private BigDecimal getTotalCreancesClients() {
        return factureVenteRepository.findAll().stream()
                .filter(f -> f.getStatut() != StatutFactureVente.PAYEE)
                .map(FactureVente::getTotalTtc)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    // Ajoute aussi celle-ci pour l'Audit (utilisée dans le dashboard DAF)
    private List<Map<String, Object>> getAnomaliesAudit() {
        List<Map<String, Object>> anomalies = new ArrayList<>();
        factureAchatRepository.findAll().forEach(f -> {
            if (f.getBonCommande() != null) {
                BigDecimal montantBC = f.getBonCommande().getMontantTotalTtc();
                BigDecimal montantFac = f.getMontantTotalTtc();
                
                // Si l'écart est supérieur à 0.01 (pour éviter les erreurs d'arrondi)
                if (montantFac.subtract(montantBC).abs().compareTo(new BigDecimal("0.01")) > 0) {
                    Map<String, Object> a = new HashMap<>();
                    a.put("fac", f.getNumeroFactureFournisseur());
                    a.put("bc", f.getBonCommande().getReferenceBc());
                    a.put("montantBC", montantBC);
                    a.put("montantFac", montantFac);
                    a.put("ecart", montantFac.subtract(montantBC));
                    anomalies.add(a);
                }
            }
        });
        return anomalies;
    }
}