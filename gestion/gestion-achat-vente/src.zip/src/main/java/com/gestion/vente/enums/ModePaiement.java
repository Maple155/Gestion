package com.gestion.vente.enums;

public enum ModePaiement {
    VIREMENT,
    ESPECES,
    CARTE,
    CHEQUE,
    MOBILE
}
