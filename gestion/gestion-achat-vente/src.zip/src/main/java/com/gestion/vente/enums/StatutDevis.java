package com.gestion.vente.enums;

public enum StatutDevis {
    BROUILLON,
    A_VALIDER,
    VALIDE,
    EXPIRE,
    ANNULE
}
