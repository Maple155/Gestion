package com.gestion.vente.enums;

public enum StatutFactureVente {
    EMISE,
    PAYEE,
    ANNULEE
}
