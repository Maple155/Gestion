package com.gestion.vente.enums;

public enum StatutLigneCommande {
    EN_ATTENTE,
    RESERVEE,
    LIVREE,
    ANNULEE
}
