package com.gestion.vente.enums;

public enum StatutPaiement {
    ENREGISTRE,
    ANNULE
}
