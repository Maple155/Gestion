package com.gestion.vente.enums;

public enum StatutCommandeClient {
    EN_ATTENTE,
    CONFIRMEE,
    EN_PREPARATION,
    LIVREE,
    FACTUREE,
    ANNULEE
}
