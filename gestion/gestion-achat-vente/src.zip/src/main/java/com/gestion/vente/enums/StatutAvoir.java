package com.gestion.vente.enums;

public enum StatutAvoir {
    EMIS,
    ANNULE
}
