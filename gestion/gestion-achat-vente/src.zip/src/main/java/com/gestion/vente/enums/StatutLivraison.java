package com.gestion.vente.enums;

public enum StatutLivraison {
    EN_PREPARATION,
    PRETE,
    LIVREE,
    ANNULEE
}
